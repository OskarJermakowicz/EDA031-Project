#ifndef EDA031_PROJECT_STORAGE_EXCEPTIONS_H
#define EDA031_PROJECT_STORAGE_EXCEPTIONS_H

struct NGAlreadyExistsException {
};
struct NGDoesNotExistException {
};
struct ARTDoesNotExistException {
};
#endif //EDA031_PROJECT_STORAGE_EXCEPTIONS_H
